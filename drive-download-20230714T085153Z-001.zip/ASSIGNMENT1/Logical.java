class Logical

{
  public static void main(String[]args)
  {
   
    boolean a=true;
    boolean b=false;
   
    System.out.println("AND result is: "+(true&&true));
    System.out.println("AND result is: "+(true&&false));
    System.out.println("OR result is: "+(true||false));
    System.out.println("OR result is: "+(false||false));
    System.out.println("AND result is: "+(a&&b));
    System.out.println("OR result is: "+ (a||b));
 
  }
 }
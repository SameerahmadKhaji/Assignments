class Relational
 
{
   public static void main(String[]args)
  {
    int a=10;
    int b=20;
    int c=5;
    int d=2;
   
     System.out.println("Equal result: "+(a==b));
     System.out.println("UnEqual result: "+(a!=b));
     System.out.println("Greater Than result: "+(a>b));
     System.out.println("Lesser Than result: "+(a<b));
     System.out.println("Greater Than or Equal to result: "+(a>=d));
     System.out.println("Lesser Than or Equal to result: "+(a<=d));

  }}
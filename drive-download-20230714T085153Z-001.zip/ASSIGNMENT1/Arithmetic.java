class Arithmetic
{
 public static void main(String[]args)

{
  
   int a=10;
   int b=20;
   int c=5;
   int d=2;
  
   System.out.println("The Addition result is: "+(a+b));
   System.out.println("The Subtraction result is: "+(b-a));
   System.out.println("The Multiplication result is: "+(b*a));
   System.out.println("The Division result is: "+(a/d));
   System.out.println("The Remainder result is: "+(a%d));

}
}
  